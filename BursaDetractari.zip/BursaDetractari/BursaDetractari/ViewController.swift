//
//  ViewController.swift
//  BursaDetractari
//
//  Created by tahir on 12/13/19.
//  Copyright © 2019 tahir. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

